ICON_PATH="/storage/.xbmc/addons/driver.remote.xbmc-ps3d/pixmaps"
